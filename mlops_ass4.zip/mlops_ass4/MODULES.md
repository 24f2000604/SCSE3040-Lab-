# Module responsibilities — Practical 04

One sentence per module, saying what its single job is.

| Module | Its one job |
|---|---|
| `delivery/__init__.py` | Marks the folder as an importable package and re-exports the handful of names the rest of the project uses, so `from delivery import train_model` just works. |
| `delivery/data.py` | Gets the delivery data ready: reads the CSV into a table and splits it into training and test sets. |
| `delivery/features.py` | Describes and derives numbers for a *single* order — minutes per kilometre, average speed, and a human-readable summary. |
| `delivery/model.py` | Owns the model itself: trains it, scores it, saves it to disk and loads it back. |
| `delivery/validate.py` | Decides whether one order is usable, returning `True` only when every field is inside its allowed range. |
| `work/train.py` | The command a human runs to train the model on a CSV, report its error, and write `model.joblib`. |
| `work/predict.py` | The command a human runs to load `model.joblib` and print the predicted delivery time for one order. |

`train.py` and `predict.py` are *scripts*, not part of the package: they hold no logic of
their own, they only wire the package's functions together for someone at a terminal.

## Running it without a notebook

```
cd work
python train.py ../../data/delivery_times.csv
python predict.py
```
